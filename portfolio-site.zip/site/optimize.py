"""
把 Google Drive 下載下來的原始截圖，壓成作品集用的 WebP。
用法：
  1. pip install pillow
  2. 把四個資料夾放在 originals/ 底下並改名為 key：
        originals/fusheng/、originals/angle/、originals/chunho/、originals/yuanjen/
     每個資料夾裡放 Home.jpg 和內頁截圖（檔名任意）。
  3. 在 pages.txt 相同順序下，或直接依 index.html 的 pages 順序，
     把內頁截圖改名為 1.jpg、2.jpg…（Home 改成 home.jpg）。
  4. python optimize.py  → 產生 images/<key>/home.webp、1.webp…
  5. index.html 裡把 LOCAL_IMAGES 改成 true。
"""
from pathlib import Path
from PIL import Image

SRC, OUT, WIDTH, QUALITY = Path("originals"), Path("images"), 1600, 78
for folder in SRC.iterdir():
    if not folder.is_dir(): continue
    dest = OUT / folder.name; dest.mkdir(parents=True, exist_ok=True)
    for f in folder.iterdir():
        if f.suffix.lower() not in (".jpg", ".jpeg", ".png"): continue
        im = Image.open(f).convert("RGB")
        if im.width > WIDTH:
            im = im.resize((WIDTH, round(im.height * WIDTH / im.width)), Image.LANCZOS)
        # WebP 最長邊上限 16383px，過長的整頁截圖切掉底部
        if im.height > 16000: im = im.crop((0, 0, im.width, 16000))
        target = dest / (f.stem.lower() + ".webp")
        im.save(target, "WEBP", quality=QUALITY, method=6)
        print(f"{f} -> {target} ({target.stat().st_size // 1024} KB)")
