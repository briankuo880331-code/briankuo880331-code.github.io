把壓縮後的截圖放在這裡，結構：
images/fusheng/home.webp, 1.webp … 11.webp
images/angle/home.webp,   1.webp … 8.webp
images/chunho/home.webp,  1.webp … 6.webp
images/yuanjen/home.webp, 1.webp … 12.webp
編號順序 = index.html 裡每個專案 pages 陣列的順序。
