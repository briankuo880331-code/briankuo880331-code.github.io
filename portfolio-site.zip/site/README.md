# 網頁設計作品集

單一 HTML 檔的靜態作品集，可直接放上 GitHub Pages。

## 檔案
- `index.html` — 整個網站（HTML / CSS / JS 都在裡面）
- `images/` — 壓縮後的作品截圖（見 images/README.md）
- `optimize.py` — 把原始截圖批次壓成 WebP
- `.nojekyll` — 告訴 GitHub Pages 不要用 Jekyll 處理

## 更新內容
專案文字都在 `index.html` 最下方 `<script>` 的 `projects` 物件裡；
新增專案 = 在 `projects` 加一筆，並把 key 加進 `order` 陣列。
